#!/bin/bash
#
#  Copyright 2005-2014 Red Hat, Inc.
#
#  Red Hat licenses this file to you under the Apache License, version
#  2.0 (the "License"); you may not use this file except in compliance
#  with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
#  implied.  See the License for the specific language governing
#  permissions and limitations under the License.
#

## defines the default environment settings

# add something like this:
#

export MAIN="io.fabric8.jube.main.Main"
export JUBE_IMPORT_URLS="mvn:io.fabric8.quickstarts/fabric8-quickstarts-parent/2.0.29/zip/app,mvn:io.fabric8.jube.images.fabric8/apps/2.0.29/zip/app"
export HTTP_PORT="8585"
export SERVICE="jube"
export HAWTIO_AUTHENTICATIONENABLED="false"
export SERVICE_NAME="Jube :: Jube"

# export MAIN="MyClassName"

